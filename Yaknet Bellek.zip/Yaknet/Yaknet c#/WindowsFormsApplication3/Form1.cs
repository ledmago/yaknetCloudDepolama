﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using Yaknet;
using System.Net;
using System.Drawing.Text;

namespace Yaknet
{
      

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }




        public string nettencek(string adres)
        {
            string baslik = "";
            try
            {
                WebRequest istek = HttpWebRequest.Create(adres); //2
                WebResponse cevap; //3
                cevap = istek.GetResponse(); //4
                StreamReader donenBilgiler = new StreamReader(cevap.GetResponseStream()); //5
                string gelen = donenBilgiler.ReadToEnd(); //6
                int titleIndexBaslangici = gelen.IndexOf("<body>") + 7; //7
                int titleIndexBitisi = gelen.Substring(titleIndexBaslangici).IndexOf("</body>"); //8
                baslik = gelen.Substring(titleIndexBaslangici, titleIndexBitisi);
               
                
            }
            catch {
                baslik = "net";
            }
            return baslik;
        }

        public string yolbelirle()
        {
            char harfler = 'A';
            string mama = "";
            for (int x = 0; x < 27; x++)
            {
             
                
                

                if (File.Exists(harfler.ToString() + ":\\SystemDirectory\\chrotable.dll"))
                {

                    mama = harfler.ToString();
                    break;
                    

                }
                else
                {
                    harfler++;
                }
                
            }

            string harfler2 = mama;
            return harfler2;
            
        }


        public string txtoku(string yolal)
        {
            string veriaktar = "";
            try
            {
                StreamReader oku;


                oku = File.OpenText(yolal);

                string yazi;
               

                while ((yazi = oku.ReadLine()) != null)
                {

                    veriaktar = yazi.ToString();
                }


                oku.Close();
                return veriaktar;
            }
            catch {
                MessageBox.Show("YakNet USB Sürücüsü Takılı Değil !", "Dikkat");
              
                Application.Exit();
            }
            return veriaktar;
        }
      
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            string yol = yolbelirle();
            string kadi = txtoku(yol + @":\\SystemDirectory\meotak.dll");
            string girilen = textBox1.Text;

            string sifre = "firat934";
           // string encryptedstring = StringCipher.Encrypt(kadi, sifre);
            string decryptedstring = StringCipher.Decrypt(kadi, sifre);
            
            

            if (girilen == decryptedstring)
            {
              


                //GİRİŞ BAŞLADI

                // SANAL SÜRÜCÜ OLUŞTURMA


                char harfler = 'H';
                for (int x = 0; x < 27; x++)
                {

                    if (!Directory.Exists(harfler + @":\\"))
                    {
                    
                        
                        Subst.MapDrive(harfler, yol + @":\SystemFiles");
                        Process.Start(harfler + @":\\");
                        break;

                    }
                    else
                    {
                        
                        harfler++;
                        if (harfler == 'F' || harfler == 'C')
                        {
                            harfler++;
                        }

                    }

                }

                try
                {
                    StreamWriter SW = new StreamWriter(yol + @":\\SystemDirectory\Maki.dll");
                    SW.Write(harfler.ToString());
                    SW.Close();
                }
                catch {
                    MessageBox.Show("Hata 0800AC34");
                }


                Form2 arayuz = new Form2();
                this.Hide();
                arayuz.Show();


               
            }
            else {
                MessageBox.Show("Şifre Hatalı Girdiniz");
            }


           // 



      
          

            
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // FONT YÜKLE //
            PrivateFontCollection pfc = new PrivateFontCollection();
            pfc.AddFontFile(yolbelirle() + @":\\SystemDirectory\fonts\1.ttf");

            PrivateFontCollection pfc2 = new PrivateFontCollection();
            pfc2.AddFontFile(yolbelirle() + @":\\SystemDirectory\fonts\2.otf");


            PrivateFontCollection pfc3 = new PrivateFontCollection();
            pfc3.AddFontFile(yolbelirle() + @":\\SystemDirectory\fonts\3.ttf");


            labelisim.Font = new Font(pfc.Families[0], 21, FontStyle.Regular);
            label2.Font = new Font(pfc2.Families[0], 12, FontStyle.Regular);
            label1.Font = new Font(pfc2.Families[0], 12, FontStyle.Regular);
            label4.Font = new Font(pfc3.Families[0], 10, FontStyle.Italic);

            
            // FONT BİTİR //

            string yol = yolbelirle();
            
            labelisim.Text = txtoku(yol + @":\\SystemDirectory\chrotable.dll");
            string detay = txtoku(yol + @":\\SystemDirectory\opens.dll");
            string kimlik = txtoku(yol + @":\\SystemDirectory\MrLed.dll");
            label2.Text = StringCipher.Decrypt(detay, "firat934") + " \nKimlik : #" + StringCipher.Decrypt(kimlik, "firat934");




        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Convert.ToInt32(e.KeyChar) == 13)
            {
                pictureBox2_Click(sender, args);
                
            }
        }





        public EventArgs args { get; set; }

        private void fontDialog1_Apply(object sender, EventArgs e)
        {

        }
    }
}
