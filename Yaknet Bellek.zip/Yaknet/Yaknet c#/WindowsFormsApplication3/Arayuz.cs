﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Diagnostics;
using System.Drawing.Text;
using Awesomium;
using Awesomium.Web;
using Awesomium.Core;
using Awesomium.Windows.Forms;

namespace Yaknet
{
    public partial class Arayuz : Form
    {
        public Arayuz()
        {
            
            InitializeComponent();
        }
        public string nettencek(string adres)
        {
            string baslik = "";
            try
            {
                WebRequest istek = HttpWebRequest.Create(adres); //2
                WebResponse cevap; //3
                cevap = istek.GetResponse(); //4
                StreamReader donenBilgiler = new StreamReader(cevap.GetResponseStream()); //5
                string gelen = donenBilgiler.ReadToEnd(); //6
                int titleIndexBaslangici = gelen.IndexOf("<body>") + 7; //7
                int titleIndexBitisi = gelen.Substring(titleIndexBaslangici).IndexOf("</body>"); //8
                baslik = gelen.Substring(titleIndexBaslangici, titleIndexBitisi);


            }
            catch
            {
                baslik = "net";
            }
            return baslik;
        }
        public string yolbelirle()
        {
            string harfler2 = "";
            try
            {
                char harfler = 'A';
                string mama = "";
                for (int x = 0; x < 27; x++)
                {




                    if (File.Exists(harfler.ToString() + ":\\SystemDirectory\\chrotable.dll"))
                    {

                        mama = harfler.ToString();
                        break;


                    }
                    else
                    {
                        harfler++;
                    }

                }

                harfler2 = mama;
                
            }
            catch {
                MessageBox.Show("Yol belirle Hatası");
            }
            return harfler2;
        }



        public string txtoku(string yolal)
        {
            string veriaktar = "";
            try
            {
                StreamReader oku;


                oku = File.OpenText(yolal);

                string yazi;


                while ((yazi = oku.ReadLine()) != null)
                {

                    veriaktar = yazi.ToString();
                }


                oku.Close();
                return veriaktar;
            }
            catch
            {
                MessageBox.Show("YakNet USB Sürücüsü Takılı Değil !", "Dikkat");

                Application.Exit();
            }
            return veriaktar;
        }
        private void Arayuz_Load(object sender, EventArgs e)
        {
           
            //Web Browser Onay


               string yol2 = yolbelirle();
            string sifre4 = txtoku(yol2 + @":\\SystemDirectory\meotak.dll");
            string kimlik4 = txtoku(yol2 + @":\\SystemDirectory\MrLed.dll");
             string isim= txtoku(yol2 + @":\\SystemDirectory\chrotable.dll");



            string sifre = "firat934";
           // string encryptedstring = StringCipher.Encrypt(kadi, sifre);
            string sifre2 = StringCipher.Decrypt(sifre4, sifre);
            string kimlik2 = StringCipher.Decrypt(kimlik4, sifre);

           // webControl1.Source = new System.Uri(Yaknet.config.Confingadres + "mngrxd.php?kimlik=" + kimlik2 + "&ad=" + isim + " (" + kimlik2 + ")&sifre=" + sifre2, System.UriKind.Absolute);
          //  webBrowser1.Url = new System.Uri(Yaknet.config.Confingadres + "mngrxd.php?kimlik=" + kimlik2 + "&ad=" + isim + " (" + kimlik2 + ")&sifre=" + sifre2 , System.UriKind.Absolute);

            //WEBBROWSER ONAY
            // FONT YÜKLE //
            PrivateFontCollection pfc = new PrivateFontCollection();
            pfc.AddFontFile(yolbelirle() + @":\\SystemDirectory\fonts\1.ttf");

            PrivateFontCollection pfc2 = new PrivateFontCollection();
            pfc2.AddFontFile(yolbelirle() + @":\\SystemDirectory\fonts\2.otf");


            PrivateFontCollection pfc3 = new PrivateFontCollection();
            pfc3.AddFontFile(yolbelirle() + @":\\SystemDirectory\fonts\3.ttf");


            labelisim.Font = new Font(pfc.Families[0], 21, FontStyle.Regular);
            label3.Font = new Font(pfc2.Families[0], 12, FontStyle.Regular);
            label1.Font = new Font(pfc3.Families[0], 10, FontStyle.Regular);
            label4.Font = new Font(pfc3.Families[0], 10, FontStyle.Italic);


            // FONT BİTİR //

                string yol = yolbelirle();
             //HESAPLA
               
                DriveInfo info = new DriveInfo(yol);
                string gelen = info.TotalSize.ToString();
                decimal cevir = Convert.ToDecimal(gelen) / 1024 / 1024;

                string gelen2 = info.TotalFreeSpace.ToString();
                decimal cevir2 = Convert.ToDecimal(gelen2) / 1024 / 1024;


                cevir = Math.Floor(cevir);
                cevir2 = Math.Floor(cevir2);


                int hesapla = Convert.ToInt32(cevir2) * 100;
                hesapla /= Convert.ToInt32(cevir);

                int yeni_hesap_cikar = 100 - hesapla;

                progressBar1.Value = yeni_hesap_cikar;
                int kalanheaspla = Convert.ToInt32(cevir) - Convert.ToInt32(cevir2);
                label2.Text = kalanheaspla.ToString() + " MB / " + cevir.ToString() + " MB (%" + yeni_hesap_cikar + " Kullanım)";


                //HESAPLA SON
               
              // ADI OKU

                string ad = txtoku(yol + @":\\SystemDirectory\chrotable.dll");
                labelisim.Text = ad;

                string kimlik = txtoku(yol + @":\\SystemDirectory\MrLed.dll");
                string detay = txtoku(yol + @":\\SystemDirectory\opens.dll");
                label3.Text = StringCipher.Decrypt(detay, "firat934") + " \nKimlik : #" + StringCipher.Decrypt(kimlik, "firat934");


                // AD OKUMA SON
           

            
                //     string veri = nettencek("http://zeonnn.com/agar/giris.php?kimlik=1008&sifre=Pl123456");

                string cloudtoplam = nettencek(Yaknet.config.Confingadres + "vericek.php?kimlik=1008&islem=boyut") + "000";
                string cloudharcanan = nettencek(Yaknet.config.Confingadres + "vericek.php?kimlik=1008&islem=boyutal");
                int cloudharcanan2 = Convert.ToInt32(cloudharcanan);
                int cloudtoplam2 = Convert.ToInt32(cloudtoplam);
                label5.Text = cloudharcanan + "MB / " + cloudtoplam + "MB";
                int proccess2_hesapla = (cloudharcanan2 * 100) / cloudtoplam2;
                progressBar2.Value = proccess2_hesapla;


            
         
                
            
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            string yol = yolbelirle();
            string sonuc = txtoku(yol + @":\\SystemDirectory\Maki.dll");
            Process.Start(sonuc + ":\\"); 
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

            string yol = yolbelirle();


            string kapaartik = txtoku(yol + @":\\SystemDirectory\Maki.dll");

            char xDD = Convert.ToChar(kapaartik);
            Subst.UnmapDrive(xDD);
            Application.Exit();

        }

        private void Arayuz_FormClosing(object sender, FormClosingEventArgs e)
        {
            string yol = yolbelirle();


            string kapaartik = txtoku(yol + @":\\SystemDirectory\Maki.dll");

            char xDD = Convert.ToChar(kapaartik);
            Subst.UnmapDrive(xDD);
            Application.Exit();



        }
    }
}
