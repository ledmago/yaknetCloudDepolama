﻿<body>
<?php
include("ayar.php");
$kimlik = $_GET["kimlik"];
$islem = $_GET["islem"];
	;
	$sonuc = "Yaknet";
	$sorgus = "SELECT * FROM uyeler WHERE kimlik='$kimlik'";
		$admin_sorgus = mysql_query($sorgus, $mysqlbaglantisi) or die(mysql_error());
		$uyelers4 = mysql_fetch_array($admin_sorgus);
if($islem == "isim")
{
		$sonuc = $uyelers4["isim"];
		
}
else if($islem == "detay")
{
		$sonuc = $uyelers4["detay"];
		
}
else if($islem == "sifre")
{
		$sonuc = $uyelers4["sifre"];
		
}
else if($islem == "boyut")
{
		$sonuc = $uyelers4["boyut"];
		
}
else if($islem == "boyutal")
{

	$path = "files/".$_GET["kimlik"];
	 $bytestotal = 0;
    $path = realpath($path);
    if($path!==false){
        foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS)) as $object){
            $bytestotal += $object->getSize();
        }
		
    }
  $sonuc = ceil($bytestotal/1024/1004);
		
		

	
}
echo $sonuc;
	    

?>
</body>