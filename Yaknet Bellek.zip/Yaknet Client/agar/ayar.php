<?php
ini_set('display_errors', TRUE);
$vt_host = "localhost"; 
$vt_kullanici = "zeonnnco_yaknet"; 
$vt_sifre = "firat934"; 
$veritabani = "zeonnnco_yaknet"; 
$mysqlbaglantisi = mysql_connect($vt_host, $vt_kullanici, $vt_sifre);
mysql_query("SET COLLATION_CONNECTION = �utf8_turkish_ci� ");
mysql_query("SET NAMUES 'utf8'");
mysql_query("SET CHARACTER SET 'utf8_turkish_ci'"); 

if(! $mysqlbaglantisi) die("MySQL�e ba�lan�lam�yor"); 

mysql_select_db($veritabani, $mysqlbaglantisi) or die ("Veritaban�na ba�lan�lam�yor");

mysql_query("SET NAMES UTF8");

?>