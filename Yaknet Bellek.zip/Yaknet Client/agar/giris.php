<body><?php
include("ayar.php");
if(isset($_GET["kimlik"]) || isset($_GET["sifre"]))
{
	
	$kimlik = $_GET["kimlik"];
	$sifre = $_GET["sifre"];
	
	$sorgula = mysql_query("SELECT * FROM `uyeler` WHERE kimlik = '$kimlik' and sifre = '$sifre'");
if ($listele = mysql_fetch_array($sorgula)) 
{
	echo "OK";
}
else
{
	echo "Hata";
	
}
	
}


?></body>