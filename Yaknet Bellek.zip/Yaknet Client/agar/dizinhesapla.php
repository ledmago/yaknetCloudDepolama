<?
$kimlik = $_GET["kimlik"];
    function GetDirectorySize($path){
    $bytestotal = 0;
    $path = realpath($path);
    if($path!==false){
        foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS)) as $object){
            $bytestotal += $object->getSize();
        }
    }
    return ceil($bytestotal/1024/1004);
}

if(isset($_GET["kimlik"]))
echo GetDirectorySize("files/".$kimlik);
?>